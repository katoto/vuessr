<template>
    <div>
        <div class="jie-detail jie-detail-nomb">
            <div class="jie-detailL">
                <div class="t-nav"></div>
                <ul class="t-detail" v-if="match">
                    <li>
                        <div class="t-img">
                            <img :src="match.awaylogo">
                        </div>
                        {{match.awaysxname}}(客)
                    </li>
                    <li>
                        <div class="t-img">
                            <img :src="match.homelogo">
                        </div>
                        {{match.homesxname}}(主)
                    </li>
                </ul>
            </div>
            <div class="jie-detailR">
                <div id="slider" class="slide-box mr40">
                    <div class="t-nav">
                        <div class="responsive">
                            <div class="wjie" >1节</div>
                        </div>
                    </div>
                    <!--<ul class="t-detail">-->
                        <!--<li class="responsive" v-for="scoreLists in [awaySectionScoreList, homeSectionScoreList]">-->
                            <!--<div class="wjie" v-for="(score,index) in scoreLists">{{score}}</div>-->
                        <!--</li>-->
                    <!--</ul>-->
                </div>

                <div class="zongfen-box">
                    <div class="zongfen gray-zf">总分</div>
                    <div class="zongfen red-zf">{{match.awayscore || '-'}}</div>
                    <div class="zongfen red-zf">{{match.homescore || '-'}}</div>
                </div>
                <div class="sli-line"></div>
            </div>
        </div>

        {{eventList}}
        <!--<me-sports src="detail-page/comment/me-sports.html" drunk-if="subtab == 'event'" requesting="{{isRequesting}}" on-size="hasNews=!!$event.args[0]" leagueid="{{match.matchid}}" init-size="{{match.status == StatusCode.NOT_STARTED?5:3}}" homeid="{{match.homeid}}" awayid="{{match.awayid}}" status="{{match.status}}" matchtime="{{match.matchdate}}" vtype="2"></me-sports>-->

        <!--<div class="gl-nav">文字直播</div>-->
        <!--<div class="zhedie-box"-->
        <!--drunk-if="eventlist && eventlist.length"-->
        <!--drunk-on="click: expandedSection[index] = !expandedSection[index]"-->
        <!--drunk-repeat="section,index in eventlist">-->

        <!--<div class="zhedie-nav" drunk-class="{'dang-list-l-on': expandedSection[index]}" drunk-if="section.length">-->
        <!--{{nameList[index]}}-->
        <!--<span class="live" drunk-if="match.status == OrderedStatusCode[index]">Live</span>-->
        <!--<span class="sh-arrow" drunk-class="{'rotate180': !expandedSection[index]}"></span>-->
        <!--</div>-->
        <!--<div class="tree-box"-->
        <!--drunk-class="{'green-s': match.status == OrderedStatusCode[index] && match.status != StatusCode.ENDED, 'gray-s': match.status == StatusCode.ENDED || match.status != OrderedStatusCode[index]}"-->
        <!--drunk-if="expandedSection[index] && section.length">-->
        <!--<div class="list" drunk-repeat="event in section">-->
        <!--<span class="timing">{{event.time}}</span>-->
        <!--<div class="dui" drunk-if="event.team">[{{event.team}}]</div>-->
        <!--<p class="jies">-->
        <!--{{event.desc}}-->
        <!--<span class="jies-bf">[{{event.awayscore}}:{{event.homescore}}]</span>-->
        <!--</p>-->
        <!--</div>-->
        <!--<div class="list">-->
        <!--<span class="timing"></span>-->
        <!--<div class="kais">开始</div>-->
        <!--</div>-->
        <!--</div>-->
        <!--</div>-->

        <!--<div class="sk-btips" v-if="eventlist && eventlist.length">500彩票网提示：-->
        <!--<br>以上数据仅供参考，请以官方公布的数据为准-->
        <!--</div>-->
    </div>
</template>

<script>
    import { BasketballStatusCode as StatusCode} from '~common/constants'
    export default{
        props:{
            eventList:{
                type:Array,
                required:true
            },
            status: {
                type: String,
                required: true
            }
        },
        data(){
            return {
                StatusCode
            }
        },
        computed:{
            match:function () {
                return this.$store.state.lqdetail.baseInfo;
            },
            eventList:function(){
                return this.$store.state.lqdetail.situation && this.$store.state.lqdetail.situation.eventlist;
            }
        },
        mounted(){

        }
    }
</script>