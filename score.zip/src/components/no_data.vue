<template>
    <div class="ui-empty" style="padding: 1.54rem 0;">
        <img src="http://tccache.500.com/mobile/widget/empty/images/12.png" class="w240">
        <div class="ui-empty-gfont">很抱歉，没有数据</div>
    </div>
</template>
<style scoped>

    .ui-empty{padding:2.72rem 0;text-align:center;}
    .ui-empty img{margin-bottom:0.933333rem;}
    .ui-empty .w240{width:3.2rem;}
    .ui-empty-gfont{font-size:0.4rem;color:#b3b3b3;margin-bottom:0.773333rem;padding:0 0.5rem;}

</style>
