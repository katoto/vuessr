[![Build Status](https://travis-ci.org/sampsonli/score.svg?branch=master)](https://travis-ci.org/sampsonli/score)
###项目介绍
1. 新比分项目， 为彩民朋友提供最新球队信息
2. 使用最新 vue ssr 服务端渲染机制

###环境搭建
1. copy项目到目录
~~~
git clone ...
~~~
2. 初始化
~~~
npm install （or yarn）
~~~



